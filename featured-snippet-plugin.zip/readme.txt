=== Featured Snippet Plugin ===
Contributors: pixeldreher
Tags: seo, featured snippet, serps, serp, google, search engine
Donate link: https://www.technicalseo.de
Requires at least: 3.7
Tested up to: 4.7.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This featured snippet plugin for WordPress integrate a small and flexible content box in your content area. It\'s your chance to beat the competition and for higher rank results.

== Installation ==
1. Activate the plugin
2. Use this shortcode in your wysiwyg editor: [featured_snippet image=\"Image URL\" image_alt=\"Alt-Attribute for your image\"]Your content for the featured snippet[/featured_snippet]

== Changelog ==
1.0 First commit